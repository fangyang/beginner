<?php
	session_start();

        error_reporting( E_ERROR | E_PARSE  );
        $host = "cs-server.usc.edu:8088";
        $db_name = "myCompany";
        $error_msg = "";

        $rootConn = mysql_connect("$host",'pseudoSystem','Jessica1125') OR die(mysql_error());

        mysql_select_db("$db_name", $rootConn) or die("cannot select DB");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Fang's Personal Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="decorate.css" type="text/css"  title="default"/>

<script type="text/javascript">

	function newMessage(thisForm)
	{

		if (thisForm.messageContent.value == "" || thisForm.messageContent.value == "-") 
		{
			alert("There is no message. Message sending fail.")
			return false;
		}

		alert("Your message has been send successfully.")
		return true;
	}

</script>


</head>

<body>

<div id="window" style="background-color: #cccccc; border:2px solid #333333; height:1270px;">

	<div id="logo" style="height:120px; background-color: #99bbbb; ">
		<div id="name">
			<div style="width:100%; height: 20px;"></div>
			<p style="margin-top:0px; margin-bottom:0;">Fang Yang</p>
			<p style="font-size: 20px;color: black; margin-top: 0;margin-bottom:0;">fangyang@usc.edu (Electrical Engineering Master)</p>
		</div>
	</div>

	<div id="panel" style=" background-color: #112222; ">
		<div class="leftdivide">
		</div>
		<div class="leftlinkicon" style="width:135px;">
		<a href="index.html" style="color:white;">Home Page</a>
		</div>
		<div class="leftdivide">
		</div>
		<div class="leftlinkicon" >
		<a href="profile.html" style="color:white;">Profile</a>
		</div>
		<div class="leftdivide">
		</div>
		<div class="leftlinkicon">
		<a href="resume_fangyang.pdf" style="color:white;">Resume</a>
		</div>
		<div class="leftdivide">
		</div>
		<!--
		<div class="leftlinkicon">
		<a style="color:white;">Work</a>
		</div>
		<div class="leftdivide">
		</div>
		<div class="leftlinkicon">
		<a style="color:white;">Codes</a>
		</div>
		<div class="leftdivide">
		</div>
		-->
		<div class="rightdivide">
		</div>
		<div class="rightlinkicon" style="width:118px;">
		<a style="color:white;" href="mailto:fangyang@usc.edu">Email me</a>
		</div>
		<div class="rightdivide">
		</div>
		<div class="rightlinkicon" style="width:200px;">
		<a style="color:white;">Leave Message</a>
		</div>
		<div class="rightdivide">
		</div>
		<div class="rightlinkicon" style="width:118px;">
		<a href="./contact.html" style="color:white;">Contact</a>
		</div>
		<div class="rightdivide">
		</div>
	</div>
	<div id="content" style="height:1060px;">
		<div id="left">
			<div>
			<img id="photo" src="person.jpg"/>
			</div >
			<div id = "projects">
				<p style="margin-left:50px;">Projects:</p>
				<div class="project">
					<div class="project_name">
					Little Vendor <br /> ( Commercial Website )
					</div>
					<input type="button" value="Demo" class="middlebutton" />
					<input type="button" value="Code" class="middlebutton" />
				</div>
				<div class="project">
					<div class="project_name" style="margin-top:3px;">
					Playing with Jpeg and JM ( Image and Video Compression )
					</div>
					<input type="button" value="Demo" class="middlebutton" />
					<input type="button" value="Code" class="middlebutton" />
				</div>
				<div class="project">
					<div class="project_name">
					Fire Department Application for USC
					</div>
					<input type="button" value="Demo" class="middlebutton" />
					<input type="button" value="Code" class="middlebutton" />
				</div>
				<div class="project">
					<div class="project_name">
					Weenix Operating System
					</div>
					<input type="button" value="Demo" class="middlebutton" />
					<input type="button" value="Code" class="middlebutton" />
				</div>
			</div>
		</div>
		<div id="introduce" style="width: 70%; float: right; text-align: center; font-family: Arial; font-size: 20px; ">
		<div id="messageBoard" style="height: 320px;">
			<p style="font-family:  fantasy; font-size: 20pt;">Leave a message here</p>
			<form method="POST" action="writeMessage.php" onsubmit="return newMessage(this)" name="messageForm">
			<div style="width:80%;  height: 140px;margin-left:10%; text-align: left;" >
			<textarea rows="6" cols="45" style="font-size: 16px; text-align:left; background-color: white; important;" name="messageContent">-</textarea> 

			<div style="width: 100%; height: 30px; padding-left: 25%; font-size: 16px; padding-top: 10px;">
			Your name: <input type="text" style="width: 100px; height: 20px;" name="leaveName" value=""> (Optional)
			</div>

			<!-- class="message_board" -->

			</div>
			<div style="width:80%; margin-left:10%; height: 50px; margin-top: 40px;" >
			<input class="middlebutton" type="submit" value="Send"  style="margin-left:28%">
			<input class="middlebutton" type="reset" value="Reset"  style="margin-left:10%">
			</div>
			</form>
		</div>

		<div id="messages" style="width: 80%; float: right; text-align: left; font-family: Arial; font-size: 16px; font-style: oblique; margin-right: 10%; ">
		<p style="font-size:18px; margin-left:20px;">Messages:</p>

<?php
		$query = "select * from messages order by leaveTime DESC";
		
		$result = mysql_query("$query", $rootConn);

		$count = 0;
		while ($row = mysql_fetch_assoc($result))
		{
		echo "<div class='oneMessage' style='width: 80%;
margin-left: 10%;
height: 100px;
margin-top: 20px;
border-bottom: solid;
font-size: 16px;
background-color: white;'>";
		echo "<div style='height: 80%; width: 100%;'><span style='font-size:18px;'>". $row['username']. ':</span><br />';
		echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' .$row['message'].  '</div>';
		echo "<div style='height: 20%;  width: 100%;'>". $row['leaveTime']. "</div>";
		echo "</div>";
		$count ++;
		if ($count >= 5) break;
		}
?>
		</div>
		
		</div>

	</div>
</div>

</body>

</html>




