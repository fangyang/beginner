<?php
	session_start();

 	error_reporting( E_ERROR | E_PARSE  );
        $host = "cs-server.usc.edu:1212";
        $db_name = "myCompany";
        $error_msg = "";

        $rootConn = mysql_connect("$host",'pseudoSystem','Jessica1125') OR die(mysql_error());

        mysql_select_db("$db_name", $rootConn) or die("cannot select DB");


	$username = $_POST['leaveName'];
	$content = $_POST['messageContent'];

	if ( $username == "" ) $username = "Anonymous";

	$string_username = mysql_real_escape_string($username);
	$string_content = mysql_real_escape_string($content);

	$result = mysql_query("insert into messages value ($string_username, $string_content, NOW()");
	
	header("location:messageBoard2.php");

	/*
	$stmt -> bindValue(1, $username, PDO::PARAM_STRING);
	$stmt -> bindValue(2, $content, PDO::PARAM_STRING);
	$affected_rows = $stmt->execute();
	*/	
?>


